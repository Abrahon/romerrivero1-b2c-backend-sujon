
from decimal import Decimal
from django.db import transaction
from rest_framework import serializers
from b2c.cart.models import CartItem
from b2c.products.models import Products
from b2c.checkout.models import Shipping
from b2c.orders.models import Order, OrderItem, OrderTracking
from b2c.checkout.serializers import ShippingSerializer
from b2c.coupons.models import Coupon
from notifications.models import Notification
from django.contrib.auth import get_user_model
from rest_framework import serializers
from django.db import transaction
from decimal import Decimal
from b2c.products.models import Products
from b2c.checkout.models import Shipping
from b2c.orders.models import Order, OrderItem
from notifications.models import Notification
from b2c.products.models import Products
from b2c.checkout.models import Shipping
from b2c.orders.models import Order, OrderItem, OrderTracking
from notifications.models import Notification
from django.contrib.auth import get_user_model
from .enums import  PaymentMethodChoices


User = get_user_model()



class OrderItemSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source="product.title", read_only=True)
    line_total = serializers.DecimalField(max_digits=12, decimal_places=2, read_only=True)

    class Meta:
        model = OrderItem
        fields = ["id", "product", "product_name", "quantity", "price", "line_total"]
        read_only_fields = ["id", "product_name", "line_total"]





class OrderTrackingSerializer(serializers.ModelSerializer):
    updated_by = serializers.StringRelatedField(read_only=True)  

    class Meta:
        model = OrderTracking
        fields = ['id', 'order', 'status', 'note', 'updated_by', 'created_at']
        read_only_fields = ['updated_by', 'created_at']

    def create(self, validated_data):
        # Assign the current user as the updater
        user = self.context['request'].user
        validated_data['updated_by'] = user

        # Create tracking entry
        tracking = OrderTracking.objects.create(**validated_data)

        # Update the order's current status
        order = tracking.order
        order.order_status = tracking.status
        order.save(update_fields=['order_status'])

        return tracking




class OrderDetailSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True, read_only=True)
    shipping_address = ShippingSerializer(read_only=True)
    tracking_history = OrderTrackingSerializer(many=True, read_only=True)
    total_amount = serializers.DecimalField(max_digits=12, decimal_places=2, read_only=True)
    discounted_amount = serializers.DecimalField(max_digits=12, decimal_places=2, read_only=True)

    class Meta:
        model = Order
        fields = [
            'id', 'order_number', 'user', 'shipping_address',
            'items', 'tracking_history', 'total_amount', 'discounted_amount',
            'is_paid', 'payment_status', 'order_status',
            'stripe_payment_intent', 'stripe_checkout_session_id', 'created_at'
        ]
        read_only_fields = [
            'user', 'order_number', 'items', 'tracking_history',
            'total_amount', 'discounted_amount', 'is_paid',
            'payment_status', 'order_status', 'stripe_payment_intent',
            'stripe_checkout_session_id', 'created_at'
        ]


class BuyNowSerializer(serializers.Serializer):
    product_id = serializers.IntegerField()
    quantity = serializers.IntegerField(default=1)
    payment_method = serializers.ChoiceField(
        choices=[("COD", "Cash on Delivery"), ("ONLINE", "Online Payment")]
    )
    # Shipping details
    full_name = serializers.CharField()
    phone_no = serializers.CharField()
    email = serializers.EmailField()
    street_address = serializers.CharField()
    apartment = serializers.CharField(required=False, allow_blank=True)
    floor = serializers.CharField(required=False, allow_blank=True)
    city = serializers.CharField()
    zipcode = serializers.CharField()

    def validate_product_id(self, value):
        try:
            Products.objects.get(id=value)
        except Products.DoesNotExist:
            raise serializers.ValidationError("Product does not exist.")
        return value

    @transaction.atomic
    def create(self, validated_data):
        request = self.context.get("request")
        user = request.user
        product = Products.objects.select_for_update().get(id=validated_data["product_id"])
        quantity = validated_data.get("quantity", 1)

        if quantity > product.available_stock:
            raise serializers.ValidationError(f"Only {product.available_stock} items available.")

        # Create shipping address
        shipping = Shipping.objects.create(
            user=user,
            full_name=validated_data["full_name"],
            phone_no=validated_data["phone_no"],
            email=validated_data["email"],
            street_address=validated_data["street_address"],
            apartment=validated_data.get("apartment", ""),
            floor=validated_data.get("floor", ""),
            city=validated_data["city"],
            zipcode=validated_data["zipcode"],
        )

        # Total amount
        total_amount = (
            product.discounted_price * quantity
            if hasattr(product, "discounted_price")
            else product.price * quantity
        )

        # Create order
        order = Order.objects.create(
            user=user,
            shipping_address=shipping,
            total_amount=total_amount,
            payment_status="pending" if validated_data["payment_method"] == "ONLINE" else "cod",
            order_status="PENDING",
            payment_method=validated_data["payment_method"],
        )

        # Create order item
        OrderItem.objects.create(
            order=order,
            product=product,
            quantity=quantity,
            price=product.discounted_price if hasattr(product, "discounted_price") else product.price,
        )

        # Update stock
        product.available_stock -= quantity
        product.save(update_fields=["available_stock"])

        # Notifications
        Notification.objects.create(
            user=user,
            title="Order Placed",
            message=f"Your order {order.order_number} has been placed successfully.",
        )

        admins = User.objects.filter(is_staff=True)
        for admin in admins:
            Notification.objects.create(
                user=admin,
                title="New Order",
                message=f"New order {order.order_number} placed by {user.email}.",
            )

        return order



# class BuyNowSerializer(serializers.Serializer):
#     product_id = serializers.IntegerField()
#     quantity = serializers.IntegerField(default=1)
#     payment_method = serializers.ChoiceField(
#         choices=PaymentMethodChoices.choices 
#     )
#     shipping_id = serializers.IntegerField()

#     def validate_product_id(self, value):
#         try:
#             Products.objects.get(id=value)
#         except Products.DoesNotExist:
#             raise serializers.ValidationError("Product does not exist.")
#         return value

#     def validate_shipping_id(self, value):
#         user = self.context['request'].user
#         if not Shipping.objects.filter(id=value, user=user).exists():
#             raise serializers.ValidationError("Invalid shipping ID for this user.")
#         return value

#     @transaction.atomic
#     def create(self, validated_data):
#         request = self.context.get("request")
#         user = request.user

#         # Get product with select_for_update to prevent race conditions
#         product = Products.objects.select_for_update().get(id=validated_data["product_id"])
#         quantity = validated_data.get("quantity", 1)

#         if quantity > product.available_stock:
#             raise serializers.ValidationError(f"Only {product.available_stock} items available.")

#         # Get shipping address
#         shipping = Shipping.objects.get(id=validated_data["shipping_id"], user=user)

#         # Calculate total amount
#         total_amount = (
#             product.discounted_price * quantity
#             if hasattr(product, "discounted_price") else product.price * quantity
#         )

#         # Create a new order
#         order = Order.objects.create(
#             user=user,
#             shipping_address=shipping,
#             total_amount=total_amount,
#             payment_status="pending" if validated_data["payment_method"] == "ONLINE" else "cod",
#             order_status="PENDING",
#             payment_method=validated_data["payment_method"],
#         )

#         # Create order item
#         OrderItem.objects.create(
#             order=order,
#             product=product,
#             quantity=quantity,
#             price=product.discounted_price if hasattr(product, "discounted_price") else product.price,
#         )

#         # Update product stock
#         product.available_stock -= quantity
#         product.save(update_fields=["available_stock"])

#         return order
